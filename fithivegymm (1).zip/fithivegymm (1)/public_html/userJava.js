/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
/* 
 Created on : 5 Mar 2023, 11:36:38
 Author     : RyanByrne
 */
let xp = 0;
let level = 1;
const xpNeeded = 100;
const achievements = [
    {level: 5, name: 'Level 5 Reached', unlocked: false},
    {level: 10, name: 'Level 10 Reached', unlocked: false},
    {level: 15, name: 'Level 15 Reached', unlocked: false}
];

function addXP() {
    xp += 20;
    if (xp >= xpNeeded) {
        xp = 0;
        levelUp();
    }
    updateXPBar();
}

function levelUp() {
    level++;
    document.getElementById('level').textContent = `Level ${level}`;
    document.getElementById('profile-usertitle-level').textContent = `Level ${level}`;

    unlockAchievements();
}

function unlockAchievements() {
    achievements.forEach((achievement) => {
        if (level >= achievement.level && !achievement.unlocked) {
            achievement.unlocked = true;
            const achievementElement = document.createElement('div');
            achievementElement.classList.add('achievement');
            achievementElement.textContent = `Achievement Unlocked: ${achievement.name}`;
            document.getElementById('achievements').appendChild(achievementElement);
        }
    });
}

function updateXPBar() {
    const xpBar = document.getElementById('xp-progress');
    xpBar.style.width = `${(xp / xpNeeded) * 100}%`;
}

function updatePlaceholder() {
    var Name = document.getElementById("Name");
    var placeholder = document.getElementById("profile-usertitle-name");
    placeholder.innerHTML = Name.value;
}